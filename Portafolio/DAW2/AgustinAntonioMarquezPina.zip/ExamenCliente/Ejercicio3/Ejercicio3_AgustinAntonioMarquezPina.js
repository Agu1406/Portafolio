// Roberto, si lees esto, apruebame por favor.

// Creamos una variable que pide al usuario un número usando prompt
let numero = Number(prompt("Intro"))