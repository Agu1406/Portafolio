alert("Bienvenido/a a Segundo de DAW");

console.log("Estudias en el IES Arquitecto Ventura Rodriguez")
