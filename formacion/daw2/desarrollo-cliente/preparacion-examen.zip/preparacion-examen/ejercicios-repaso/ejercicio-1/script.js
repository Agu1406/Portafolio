/**
 * No utilizar variables del tipo var (var = numero), están obsoletas.
 */

