/**
 * No utilizar variables del tipo var (var = numero), están obsoletas.
 */

let parrafo = document.getElementById("adrian");

parrafo.onclick = () => {
    alert("¡Uy! Me haces cosquillas")
}