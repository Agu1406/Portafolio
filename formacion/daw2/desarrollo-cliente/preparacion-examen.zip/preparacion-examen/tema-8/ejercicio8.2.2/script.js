/**
 * No utilizar variables del tipo var (var = numero), están obsoletas.
 */

let parrafo = document.getElementById("guido");

parrafo.addEventListener("click", () => { alert("Me has hecho click") });