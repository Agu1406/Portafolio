package es.daw2.ej2spring.controladores;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
/**
 * el uso de "@GetMappping" sirve para mapear la ruta de las clases,
 * si abrimos el navegador en localhost/conversación entonces el
 * "@GetMapping" permitiria identidicar que esa es la clase que se
 * debe ejecutar, sirve para defenir la URL.
 */
@RestController
public class EpiBlasController {
    /**
     * Función dialogo, returna un String por pantalla.
     * 
     * @return el String definido.
     */
    @GetMapping("/conversacion")
    public String dialogo() {
        return "¡Hola Epi! ¡Hola Blas! ¿Estás bien?";
    }
    /**
     * Función dialogante que recibe en la URL como argumento el
     * nombre de "X" persona y en base al mismo gestiona el String
     * personalizado con ese nombre.
     * 
     * @param nombre se recibe como argumento en la URL.
     * 
     * @return el String con el nombre incorporado en el.
     */
    @GetMapping("/conversacion/{nombre}")
    public String dialogante(@PathVariable String nombre) {
        return "¡Hola " + nombre + "! ¿Estás bien " + nombre + "?";
    }
    /**
     * Función que recibe dos argumentos de la URL (números enteros)
     * y en base a estos realiza una operación de suma y returna
     * el resultado de la misma.
     * 
     * @param a número entero recibido como argumento.
     * @param b número entero recibido como argumento.
     * @return la suma de los dos números anteriores.
     */
    @GetMapping("sumar/{a}/{b}")
    public int suma(@PathVariable int a, @PathVariable int b) {
        return a + b;
    }
}
