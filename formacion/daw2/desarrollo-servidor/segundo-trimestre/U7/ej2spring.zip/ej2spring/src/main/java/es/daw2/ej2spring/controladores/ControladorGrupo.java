package es.daw2.ej2spring.controladores;

import java.util.ArrayList;
import java.util.List;

import es.daw2.ej2spring.modelos.Grupo;

public class ControladorGrupo {
    
    ArrayList <Grupo> grupos = new ArrayList<>(

    List.of(

        new Grupo("Ventura", "DAW", "1"),
        new Grupo("Ventura", "DAW", "2"),
        new Grupo("Ventura", "ASIR", "1"),
        new Grupo("Ventura", "ASIR", "2"),
        new Grupo("Ventura", "SMR", "1"),
        new Grupo("Ventura", "SMR", "2"),
        new Grupo("Los Alamos", "DAM", "1"),
        new Grupo("Los Alamos", "DAM", "2"),
        new Grupo("Zayas", "SMR", "1"),
        new Grupo("Zayas", "SMR", "2")
    )

    );

    
    public ArrayList<Grupo> listarGrupos () {
        return grupos;
    }
}
