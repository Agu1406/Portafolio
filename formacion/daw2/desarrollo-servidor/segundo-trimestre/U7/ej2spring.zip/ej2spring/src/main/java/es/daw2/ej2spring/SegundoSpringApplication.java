package es.daw2.ej2spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegundoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegundoSpringApplication.class, args);
	}

}
