package UT7HerenciaPolimorfismo.Ejercicio5UT7GestionEntradasConcierto.Excepciones;
public class EntradasEnEsaZonaAgotadasException extends IllegalArgumentException {
    public EntradasEnEsaZonaAgotadasException(String s) {
    }
}
