package sistema_gestion_agricola;

import sistema_gestion_agricola.modelo.*;
import sistema_gestion_agricola.excepciones.*;
import sistema_gestion_agricola.interfaces.*;

/**
 * Esta es la clase principal donde probamos todo nuestro sistema agrícola.
 * Es como el campo de pruebas donde vemos si todo funciona bien.
 * 
 * Aquí creamos parcelas, las aramos, sembramos y cultivamos,
 * como si fuéramos agricultores de verdad.
 */
public class Main {
    public static void main(String[] args) {
        try {
            // Paso 1: Crear nuestras parcelas (como preparar el terreno de juego)
            System.out.println("=== Creando parcelas... ===");
            Parcela parcela1 = new Parcela("La Carrehuela", 10000);  // Una parcela grande
            Parcela parcela2 = new Parcela("La Puchera", 6000);      // Una mediana
            Parcela parcela3 = new Parcela("Las Laderas", 3000);     // Una pequeña

            // Paso 2: Crear los registros para cada tipo de actividad
            RegistroActividades<Arado> registroArado = new RegistroActividades<>();
            RegistroActividades<Siembra> registroSiembra = new RegistroActividades<>();
            RegistroActividades<Cultivo> registroCultivo = new RegistroActividades<>();

            // Paso 3: Crear y registrar nuestro observador que vigilará los cambios
            System.out.println("\n=== Configurando observadores... ===");
            LogEstadoParcela observador = new LogEstadoParcela();
            parcela1.agregarObservador(observador);
            parcela2.agregarObservador(observador);
            parcela3.agregarObservador(observador);

            // Paso 4: Mostrar información inicial de las parcelas
            System.out.println("\n=== Estado inicial de las parcelas ===");
            parcela1.mostrarInformacion();
            parcela2.mostrarInformacion();
            parcela3.mostrarInformacion();

            // Paso 5: Realizamos las actividades
            System.out.println("\n=== Iniciando actividades agrícolas ===");
            
            // Primero aramos todas las parcelas
            System.out.println("\n-> Arando parcelas...");
            Arado arado1 = new Arado(registroArado, parcela1);
            Arado arado2 = new Arado(registroArado, parcela2);
            Arado arado3 = new Arado(registroArado, parcela3);
            
            arado1.realizarArado();
            arado2.realizarArado();
            arado3.realizarArado();

            // Luego sembramos algunas
            System.out.println("\n-> Sembrando parcelas...");
            Siembra siembra1 = new Siembra(registroSiembra, parcela1);
            Siembra siembra2 = new Siembra(registroSiembra, parcela2);
            
            siembra1.realizarSiembra();
            siembra2.realizarSiembra();

            // Y finalmente cultivamos una
            System.out.println("\n-> Cultivando parcelas...");
            Cultivo cultivo1 = new Cultivo(registroCultivo, parcela1);
            cultivo1.realizarCultivo();

            // Paso 6: Mostramos los historiales
            System.out.println("\n=== Historial de actividades por parcela ===");
            registroArado.mostrarHistorial("La Carrehuela");
            registroSiembra.mostrarHistorial("La Carrehuela");
            registroCultivo.mostrarHistorial("La Carrehuela");

            System.out.println("\n=== Historial completo de todas las actividades ===");
            registroArado.mostrarHistorialCompleto();
            registroSiembra.mostrarHistorialCompleto();
            registroCultivo.mostrarHistorialCompleto();

        } catch (EstadoInvalidoException e) {
            System.err.println("Error en el estado de la parcela: " + e.getMessage());
        } catch (HistorialVacioException e) {
            System.err.println("Error al mostrar historial: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Error inesperado: " + e.getMessage());
        }
    }
} 