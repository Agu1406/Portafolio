package sistema_gestion_agricola.excepciones;
/**
 * Esta excepción se lanza cuando intentamos arar la parcela en un estado
 * que no permite arar. Por ejemplo, si la parcela ya está arada.
*/
public class AradoInvalidoException extends EstadoInvalidoException {
    public AradoInvalidoException() {
        super("No se puede arar la parcela en su estado actual");
    }
} 