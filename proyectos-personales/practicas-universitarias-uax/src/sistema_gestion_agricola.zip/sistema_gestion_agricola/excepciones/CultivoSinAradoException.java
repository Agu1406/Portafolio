package sistema_gestion_agricola.excepciones;
/**
 * Esta excepción se lanza cuando se intenta cultivar una parcela
 * que no ha sido previamente arada y sembrada.
 * Extiende de EstadoInvalidoException para mantener la jerarquía
 * de excepciones relacionadas con estados inválidos de la parcela.
 */

public class CultivoSinAradoException extends EstadoInvalidoException {
    public CultivoSinAradoException() {
        super("No se puede cultivar sin haber arado y sembrado la parcela primero");
    }
} 