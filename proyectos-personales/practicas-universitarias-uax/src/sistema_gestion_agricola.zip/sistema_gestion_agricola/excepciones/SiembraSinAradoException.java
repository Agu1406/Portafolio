package sistema_gestion_agricola.excepciones;
/**
 * Esta excepción se lanza cuando se intenta sembrar una parcela
 * que no ha sido previamente arada.
 * Extiende de EstadoInvalidoException para mantener la jerarquía
 * de excepciones relacionadas con estados inválidos de la parcela.
 */
public class SiembraSinAradoException extends Exception {
    public SiembraSinAradoException() {
        super("No se puede sembrar sin arar la parcela primero");
    }
} 