package sistema_gestion_agricola.excepciones;
/**
 * Esta excepción se lanza cuando el historial de actividades está vacío.
 */
public class HistorialVacioException extends Exception {
    public HistorialVacioException() {
        super("El historial de actividades está vacío");
    }
} 