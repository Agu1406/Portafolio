package sistema_gestion_agricola.excepciones;
/**
 * Esta excepción se lanza cuando se intenta realizar una actividad
 * en una parcela que no está en el estado correcto.
 * Por ejemplo, no se puede arar una parcela que ya está arada.
 * 
*/
public class EstadoInvalidoException extends Exception {
    public EstadoInvalidoException(String mensaje) {
        super(mensaje);
    }
} 