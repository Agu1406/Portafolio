package sistema_gestion_agricola.interfaces;

import sistema_gestion_agricola.excepciones.*;

/**
 * Esta interfaz es como un contrato que dice qué métodos tienen que tener
 * todas las actividades que se pueden hacer en una parcela agrícola.
 * La uso para asegurarme de que todas las actividades (arar, sembrar, etc.)
 * tengan los mismos métodos básicos.
 */
public interface ActividadAgricola {
    // Este método es para arar la tierra, es lo primero que hay que hacer
    void realizarArado() throws EstadoInvalidoException;
    
    // Este método es para sembrar, pero solo se puede hacer después de arar
    void realizarSiembra() throws SiembraSinAradoException;
    
    // Este método es para cultivar, pero necesita que ya esté sembrado
    void realizarCultivo() throws CultivoSinAradoException;
} 