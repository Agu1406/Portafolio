package sistema_gestion_agricola.interfaces;

import sistema_gestion_agricola.modelo.Parcela;

/**
 * Esta interfaz define un observador que puede actualizarse
 * sobre los cambios en el estado de una parcela.
 * 
 * @param <T> el tipo de parcela que se observa
 */
public interface ObservadorParcela {
    void actualizar(Parcela parcela, String estadoAnterior, String estadoNuevo);
} 