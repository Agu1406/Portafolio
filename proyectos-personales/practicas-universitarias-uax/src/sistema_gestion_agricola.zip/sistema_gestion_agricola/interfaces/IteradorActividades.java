package sistema_gestion_agricola.interfaces;

import java.util.Iterator;
import java.util.ListIterator;

/**
 * Esta interfaz define un iterador para recorrer las actividades
 * de forma reversa.
 * 
 * @param <T> el tipo de actividades que se iterarán
 */
public interface IteradorActividades<T> extends Iterator<T> {
    ListIterator<T> iterarReverso();
} 