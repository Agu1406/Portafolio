package sistema_gestion_agricola.modelo;

import sistema_gestion_agricola.excepciones.EstadoInvalidoException;
import sistema_gestion_agricola.interfaces.ObservadorParcela;
import java.util.ArrayList;
import java.util.List;

/**
 * Esta clase representa un terreno agrícola (parcela).
 * Es como un Tamagotchi pero de agricultura: tiene estados
 * y hay que ir cuidándola en orden (primero arar, luego sembrar...).
 * 
 * @author Estudiante de Java intentando no suspender
 * @version 1.0
 */
public class Parcela {
    // El nombre que le damos a la parcela (para no confundirla con otras)
    private String nombre;
    
    // En qué estado está: sin cultivar, arada, sembrada o cultivada
    private String estado;
    
    // Tamaño en metros cuadrados (como el área que vemos en mates)
    private double superficieMetrosCuadrados;
    
    // Lo mismo pero en hectáreas (que es como hablan los agricultores)
    private double superficieHectareas;
    
    // Y en obradas (que es una medida antigua pero aún se usa)
    private double superficieObradas;
    
    // Lista de "espías" que vigilan los cambios en la parcela
    private List<ObservadorParcela> observadores;

    /**
     * Constructor para crear una nueva parcela
     * @param nombre - cómo se va a llamar la parcela
     * @param superficieMetrosCuadrados - lo grande que es en metros cuadrados
     */
    public Parcela(String nombre, double superficieMetrosCuadrados) {
        // Guardamos el nombre y el tamaño
        this.nombre = nombre;
        this.superficieMetrosCuadrados = superficieMetrosCuadrados;
        
        // Al principio siempre está sin cultivar (como cuando empiezas un juego nuevo)
        this.estado = "sin cultivar";
        
        // Calculamos las otras medidas (es como convertir euros a dólares)
        this.superficieHectareas = superficieMetrosCuadrados / 10000;  // 1 hectárea = 10000 m²
        this.superficieObradas = superficieMetrosCuadrados / 4000;     // 1 obrada = 4000 m²
        
        // Creamos la lista de observadores (está vacía al principio)
        this.observadores = new ArrayList<>();
    }

    /**
     * Método para arar la parcela (como preparar la tierra)
     * @throws EstadoInvalidoException si intentamos arar cuando no se debe
     */
    public void arar() throws EstadoInvalidoException {
        // Solo podemos arar si está sin cultivar
        if (!estado.equals("sin cultivar")) {
            throw new EstadoInvalidoException("¡Oye! No puedes arar si no está sin cultivar");
        }
        String estadoAnterior = this.estado;
        this.estado = "arada";
        // Avisamos a los observadores del cambio
        notificarObservadores(estadoAnterior, this.estado);
    }

    public void sembrar() throws EstadoInvalidoException {
        if (!estado.equals("arada")) {
            throw new EstadoInvalidoException("La parcela debe estar arada para poder sembrarla");
        }
        String estadoAnterior = this.estado;
        this.estado = "sembrada";
        notificarObservadores(estadoAnterior, this.estado);
    }

    public void cultivar() throws EstadoInvalidoException {
        if (!estado.equals("sembrada")) {
            throw new EstadoInvalidoException("La parcela debe estar sembrada para poder cultivarla");
        }
        String estadoAnterior = this.estado;
        this.estado = "cultivada";
        notificarObservadores(estadoAnterior, this.estado);
    }

    public void agregarObservador(ObservadorParcela observador) {
        observadores.add(observador);
    }

    private void notificarObservadores(String estadoAnterior, String estadoNuevo) {
        for (ObservadorParcela observador : observadores) {
            observador.actualizar(this, estadoAnterior, estadoNuevo);
        }
    }

    /**
     * Muestra toda la info de la parcela, como una ficha técnica
     */
    public void mostrarInformacion() {
        System.out.println("=== FICHA DE LA PARCELA ===");
        System.out.println("Nombre: " + nombre);
        System.out.println("Estado actual: " + estado);
        System.out.println("Tamaño en metros²: " + superficieMetrosCuadrados);
        System.out.println("Tamaño en hectáreas: " + superficieHectareas);
        System.out.println("Tamaño en obradas: " + superficieObradas);
        System.out.println("========================");
    }

    // Getters y setters con sus comentarios
    public String getEstado() { return estado; }
    public String getNombre() { return nombre; }
} 