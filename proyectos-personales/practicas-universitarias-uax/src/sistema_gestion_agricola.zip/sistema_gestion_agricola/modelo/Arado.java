package sistema_gestion_agricola.modelo;
import sistema_gestion_agricola.excepciones.AradoInvalidoException;
import sistema_gestion_agricola.excepciones.EstadoInvalidoException;
import sistema_gestion_agricola.interfaces.ActividadAgricola;

/**
 * Esta clase representa la actividad de arar una parcela.
 * Es como cuando preparas la tierra para plantar algo,
 * pero con un tractor en vez de una pala (bueno, eso imagino).
 * 
 */
public class Arado extends ActividadParcela {
    // Aquí guardo todas las veces que se ha arado (como un diario)
    private RegistroActividades<Arado> registro;

    /**
     * Constructor para crear una nueva actividad de arado
     * @param registro - donde vamos a guardar que aramos
     * @param parcela - el terreno que vamos a arar
     */
    public Arado(RegistroActividades<Arado> registro, Parcela parcela) {
        // Llamamos al constructor del padre (es como decir "¡Papá, ayuda!")
        super(parcela);
        // Guardamos el registro para apuntar lo que hacemos
        this.registro = registro;
    }

    /**
     * Este método es el que realmente ara la parcela
     * @throws EstadoInvalidoException si intentamos arar cuando no toca
     */
    @Override
    public void realizarArado() throws EstadoInvalidoException {
        try {
            // Intentamos arar la parcela
            parcela.arar();
            // Si todo va bien, lo apuntamos en el registro
            registro.agregarActividad(parcela.getNombre(), this);
        } catch (EstadoInvalidoException e) {
            // Si algo sale mal, lanzamos nuestra propia excepción
            throw new AradoInvalidoException();
        }
    }

    // Estos métodos no hacen nada porque arar es solo arar
    @Override
    public void realizarSiembra() {
        // No hacemos nada, esto es solo para arar
    }

    @Override
    public void realizarCultivo() {
        // No hacemos nada, esto es solo para arar
    }

    /**
     * Para mostrar la actividad de forma bonita
     * @return un String que dice que esto es un arado
     */
    @Override
    public String toString() {
        return "Arado: " + super.toString();
    }
} 