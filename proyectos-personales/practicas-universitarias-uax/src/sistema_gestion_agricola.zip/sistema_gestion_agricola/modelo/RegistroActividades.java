package sistema_gestion_agricola.modelo;

import sistema_gestion_agricola.excepciones.HistorialVacioException;
import sistema_gestion_agricola.interfaces.ActividadAgricola;
import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Esta clase es como un diario super avanzado que guarda todas las actividades
 * que hacemos en cada parcela. Usa algo llamado "genéricos" (esa T que ves por ahí)
 * para poder guardar cualquier tipo de actividad (arar, sembrar, etc.).
 * 
 * 
 * @author Estudiante que por fin entiende los genéricos (más o menos)
 * @version 1.0
 * @param <T> el tipo de actividad que vamos a registrar
 */
public class RegistroActividades<T extends ActividadAgricola> {
    // Esta es nuestra "libreta mágica" que guarda las actividades por parcela
    private ConcurrentHashMap<String, List<T>> actividadesPorParcela;

    /**
     * Constructor que crea un nuevo registro vacío
     * (como empezar una libreta nueva)
     */
    public RegistroActividades() {
        // Inicializamos la libreta mágica
        this.actividadesPorParcela = new ConcurrentHashMap<>();
    }

    /**
     * Añade una nueva actividad al registro de una parcela
     * (como escribir una nueva entrada en el diario)
     * 
     * @param nombreParcela - en qué parcela se hizo la actividad
     * @param actividad - qué actividad se hizo
     */
    public void agregarActividad(String nombreParcela, T actividad) {
        // computeIfAbsent es como decir "si no existe la página para esta parcela, créala"
        actividadesPorParcela.computeIfAbsent(nombreParcela, k -> new ArrayList<>())
                            .add(actividad);
    }

    /**
     * Muestra todas las actividades de una parcela específica
     * (como leer todas las páginas del diario de una parcela)
     * 
     * @param nombreParcela - de qué parcela queremos ver el historial
     * @throws HistorialVacioException si no hay actividades registradas
     */
    public void mostrarHistorial(String nombreParcela) throws HistorialVacioException {
        List<T> actividades = actividadesPorParcela.get(nombreParcela);
        
        if (actividades == null || actividades.isEmpty()) {
            throw new HistorialVacioException();
        }
        
        System.out.println("Historial de actividades para " + nombreParcela + ":");
        for (T actividad : actividades) {
            System.out.println("  -> " + actividad);
        }
    }

    /**
     * Muestra TODAS las actividades de TODAS las parcelas
     * (como leer el diario entero de principio a fin)
     * 
     * @throws HistorialVacioException si no hay ninguna actividad registrada
     */
    public void mostrarHistorialCompleto() throws HistorialVacioException {
        if (actividadesPorParcela.isEmpty()) {
            throw new HistorialVacioException();
        }
        
        System.out.println("HISTORIAL COMPLETO DE ACTIVIDADES:");
        actividadesPorParcela.forEach((parcela, actividades) -> {
            System.out.println("\nParcela: " + parcela);
            actividades.forEach(actividad -> 
                System.out.println("  -> " + actividad));
        });
    }
} 