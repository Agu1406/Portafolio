package sistema_gestion_agricola.modelo;
import sistema_gestion_agricola.interfaces.ActividadAgricola;
import sistema_gestion_agricola.excepciones.EstadoInvalidoException;

/**
 * Esta es una clase abstracta súper importante porque tiene todo lo que comparten
 * las actividades agrícolas. La hice abstracta porque no tiene sentido crear
 * una "ActividadParcela" directamente, siempre tiene que ser algo específico
 * como arar o sembrar.
 * 
 * @author Yo (estudiante confundido)
 * @version 1.0
 */
public abstract class ActividadParcela implements ActividadAgricola {
    // Guardo la parcela donde se hace la actividad
    protected Parcela parcela;
    
    // Guardo cuándo se hizo la actividad (como un diario)
    protected String timestamp;

    /**
     * Constructor que inicializa una actividad con su parcela
     * y guarda la fecha y hora actual
     * @param parcela donde se va a hacer la actividad
     */
    public ActividadParcela(Parcela parcela) {
        // Guardo la parcela que me pasan
        this.parcela = parcela;
        // Guardo la fecha y hora actual (por si acaso)
        this.timestamp = java.time.LocalDateTime.now().toString();
    }

    /**
     * Sobreescribo toString para que me diga qué actividad se hizo y cuándo
     * Es como escribir en un diario: "Hoy hice esto en tal parcela"
     */
    @Override
    public String toString() {
        return String.format("Actividad realizada en %s - Fecha: %s", 
                           parcela.getNombre(), timestamp);
    }
} 