package sistema_gestion_agricola.modelo;

import sistema_gestion_agricola.interfaces.ObservadorParcela;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Esta clase es como un espía (pero de los buenos) que vigila los cambios
 * en las parcelas y los apunta en un registro. Es como tener un amigo
 * que te avisa cada vez que pasa algo en el campo.
 * 
 * Usa el patrón Observer, que es como tener un grupo de WhatsApp
 * donde la parcela manda mensajes cuando cambia su estado 📱

 */
public class LogEstadoParcela implements ObservadorParcela {
    // Esto es para que la fecha se vea bonita (como en los mensajes de WhatsApp)
    private static final DateTimeFormatter formatter = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    /**
     * Este método se llama automáticamente cuando una parcela cambia de estado.
     * Es como recibir una notificación en el móvil 📱
     * 
     * @param parcela - la parcela que cambió
     * @param estadoAnterior - cómo estaba antes
     * @param estadoNuevo - cómo está ahora
     */
    @Override
    public void actualizar(Parcela parcela, String estadoAnterior, String estadoNuevo) {
        // Conseguimos la hora actual (como el "visto a las..." de WhatsApp)
        String timestamp = LocalDateTime.now().format(formatter);
        
        // Imprimimos el mensaje sin emojis
        System.out.printf("[%s] Parcela '%s' cambió su estado:%n", timestamp, parcela.getNombre());
        System.out.printf("   %s -> %s%n", estadoAnterior, estadoNuevo);
        System.out.println("   ----------------------------------------");
    }
} 