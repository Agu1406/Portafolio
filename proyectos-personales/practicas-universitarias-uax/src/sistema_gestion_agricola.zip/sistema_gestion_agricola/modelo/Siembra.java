package sistema_gestion_agricola.modelo;

import sistema_gestion_agricola.excepciones.EstadoInvalidoException;
import sistema_gestion_agricola.excepciones.SiembraSinAradoException;
import sistema_gestion_agricola.interfaces.ActividadAgricola;

/**
 * Esta clase representa cuando sembramos en una parcela.
 * Es como plantar semillas en el huerto, pero a lo grande.
 * ¡Ojo! Solo podemos sembrar si antes hemos arado (tiene sentido, ¿no?).
 * 
 */
public class Siembra extends ActividadParcela implements ActividadAgricola {
    // Aquí guardamos todas las siembras que hacemos (como un diario de agricultura)
    private RegistroActividades<Siembra> registro;

    /**
     * Constructor para crear una nueva actividad de siembra
     * @param registro - donde apuntamos las siembras que hacemos
     * @param parcela - el terreno donde vamos a sembrar
     */
    public Siembra(RegistroActividades<Siembra> registro, Parcela parcela) {
        // Llamamos al constructor del padre (herencia y esas cosas)
        super(parcela);
        // Guardamos el registro para apuntar lo que hacemos
        this.registro = registro;
    }

    /**
     * Este método es el que realmente siembra en la parcela.
     * Es como el momento de "plantar" las semillas.
     * @throws SiembraSinAradoException si intentamos sembrar cuando no toca
     */
    @Override
    public void realizarSiembra() throws SiembraSinAradoException {
        try {
            // Intentamos sembrar la parcela
            parcela.sembrar();
            // Si todo va bien, lo apuntamos en nuestro diario (registro)
            registro.agregarActividad(parcela.getNombre(), this);
        } catch (EstadoInvalidoException e) {
            // ¡Ups! Algo salió mal, probablemente no aramos antes
            throw new SiembraSinAradoException();
        }
    }

    // Estos métodos están vacíos porque esta clase solo se encarga de sembrar
    @Override
    public void realizarArado() {
        // No hacemos nada, esto es solo para sembrar
    }

    @Override
    public void realizarCultivo() {
        // No hacemos nada, esto es solo para sembrar
    }

    /**
     * Para mostrar la siembra de forma bonita cuando la imprimimos
     * @return un String que dice que esto es una siembra
     */
    @Override
    public String toString() {
        return "Siembra: " + super.toString();
    }
} 