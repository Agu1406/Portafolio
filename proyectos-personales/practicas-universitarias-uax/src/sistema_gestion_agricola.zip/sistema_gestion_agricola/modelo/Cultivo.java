package sistema_gestion_agricola.modelo;
import sistema_gestion_agricola.excepciones.CultivoSinSiembraException;
import sistema_gestion_agricola.excepciones.EstadoInvalidoException;
import sistema_gestion_agricola.excepciones.CultivoSinAradoException;
import sistema_gestion_agricola.interfaces.ActividadAgricola;

/**
 * Esta clase representa la actividad de cultivar una parcela.
 * Es como la fase final, cuando ya cuidamos las plantas que sembramos.
 * ¡Importante! Solo podemos cultivar si ya hemos sembrado antes
 * (igual que no puedes cuidar plantas que no has plantado, ¿verdad?).
 * 
 */
public class Cultivo extends ActividadParcela  {
    // Aquí guardamos el registro de todos los cultivos (como un diario de jardinería)
    private RegistroActividades<Cultivo> registro;

    /**
     * Constructor para crear una nueva actividad de cultivo
     * @param registro - donde apuntamos los cultivos que hacemos
     * @param parcela - el terreno que vamos a cultivar
     */
    public Cultivo(RegistroActividades<Cultivo> registro, Parcela parcela) {
        // Llamamos al constructor del padre (es como pedir ayuda a papá/mamá)
        super(parcela);
        // Guardamos el registro para apuntar lo que hacemos
        this.registro = registro;
    }

    /**
     * Este método es el que realmente cultiva la parcela.
     * Es como regar y cuidar las plantas que ya sembramos.
     * @throws CultivoSinSiembraException si intentamos cultivar cuando no toca
     */
    @Override
    public void realizarCultivo() throws CultivoSinAradoException {
        try {
            // Intentamos cultivar la parcela
            parcela.cultivar();
            // Si todo va bien, lo apuntamos en nuestro diario (registro)
            registro.agregarActividad(parcela.getNombre(), this);
        } catch (EstadoInvalidoException e) {
            // ¡Ups! Algo salió mal, probablemente no sembramos antes
            throw new CultivoSinAradoException();
        }
    }

    // Estos métodos están vacíos porque esta clase solo se encarga de cultivar
    @Override
    public void realizarArado() {
        // No hacemos nada, esto es solo para cultivar
    }

    @Override
    public void realizarSiembra() {
        // No hacemos nada, esto es solo para cultivar
    }

    /**
     * Para mostrar el cultivo de forma bonita cuando lo imprimimos
     * @return un String que dice que esto es un cultivo
     */
    @Override
    public String toString() {
        return "Cultivo: " + super.toString();
    }
} 